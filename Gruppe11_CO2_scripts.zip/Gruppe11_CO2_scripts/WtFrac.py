from constants import *
import numpy as np

# Function to calculate the weight fraction of CO2 in the solution
def WtFracCO2(alpha):
    MwCO2 = Mw[0]
    # Calculate the weight fraction of CO2
    wc = (MwCO2 * alpha) / ((1 + 0.7 / 0.3) * MwMEA)
    return wc

# Function to convert mole fractions to weight fractions
def MolarToWtFrac(Xlist): 
    Mwt = [Mw[0], Mw[1], Mw[2], Mw[3], MwMEA] 
    # Convert the Mwt list into a numpy array
    Mwt = np.array(Mwt)
    # Convert the Xlist list into a numpy array
    Xlist = np.array(Xlist)

    # Calculate the total molar weight of the solution
    Mwt_Total = sum(Xlist * Mwt)
    
    # Create an empty list to hold the weight fractions
    w_liste = []
    for k in range(len(Xlist)):
        # Calculate the weight fraction of each component and add it to the list
        w_liste.append(Xlist[k] * Mwt[k] / Mwt_Total)

    return w_liste
