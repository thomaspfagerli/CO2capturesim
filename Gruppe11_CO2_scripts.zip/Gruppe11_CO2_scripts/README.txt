-- Oversikt over moduler og funksjoner --

De fleste funksjonene har kommentarer før og underveis for å gi en pekepinn på hvordan
de fungerer

Følgende moduler er vedlagt:

- compression.py
- constants.py
- enthalpy.py
- main.py
- MassBalance.py
- WtFrac.py
- partialtrykk.py

-- Compression --
Modul for kompressorberegninger
Funksjoner for å regne ut temperatur etter kompressjon, varmeoverføring, akselarbeid, 
ett-stegs ogtre-stegs kompressjon.

-- Constants --
Gitt konstant fil basert på siste siffer i gruppernummer. Vårt tilfelle konstantfil 1, 
pga gruppe 11. Konstantfilen er tallverdier som blir brukt i utregningene i de andre 
filene. Verdier for trykk, temperatur, molarmasse, entalpi, varmekapasitet og diverse. 

-- Enthalpy --
Modul med funksjoner for beregning av varmekapasiteter, entalpi og temperatur

-- MassBalance --
Modul med modell for massebalansen
Modul for å sette opp likningene for systemet og diverse kjente og ukjente variabler

-- WtFrac --
Modul med funksjoner som håandterer utregninger av vektfraksjoner, evt. andre
omregninger.

-- Main --
Hovedfil som setter sammen andre moduler, initaliserer massesimulatoren og printer ut 
interessante verdier. 

-- partialtrykk -- 
Modul for å regne ut og plotte partialtrykk CO2 mot temperatur og alpha
