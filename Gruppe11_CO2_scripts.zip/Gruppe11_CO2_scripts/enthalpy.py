from constants import *
from MassBalance import *
from scipy.integrate import quad
from enthalpy import *
import numpy as np
import scipy.optimize


# define function to calculate specific heat of water
def cp_H2O(T):
    return Aw + (Bw * T) + (Cw * (T ** 2))


# define function to calculate specific heat of monoethanolamine (MEA)
def cp_MEA(T):
    return Aa + (Ba * T) + (Ca * (T ** 2))


# define function to calculate specific heat of carbon dioxide (CO2)
def cp_CO2(T):
    return Ac + (Bc * T)


# define function to calculate specific heat of MEA solution
def cp_MEA_sol(T):
    return ((1 - waMEA) * cp_H2O(T)) + (waMEA * cp_MEA(T)) + waMEA*(1 - waMEA) * (As + Bs*T + Cs*waMEA*((T - 273.15)**(-1.5859)))


# define function to calculate integral of a given specific heat function
def cp_integral(T1, Cp_function, T0=Tref_K):
    Integral = quad(Cp_function, T0, T1)
    return Integral[0]


# define function to calculate enthalpies of each component in a given mixture
def enthalpies(MassesAndFracs):
    gases = [1, 2, 8, 9]
    hf = [None] * 9
    
    # iterate through each component in the mixture
    for k in range(len(MassesAndFracs)):
        if k == 6:
            T[k] = 'Unknown'  # if T[k] is not known, set it to 'Unknown'
        elif k + 1 in gases:  # if component is a gas, calculate its enthalpy using enthalpyGases function
            Tstream_K = T[k] + 273.15
            h_stream = enthalpyGases(MassesAndFracs[k], Tstream_K)
            hf[k] = h_stream
        else:  # otherwise, calculate its enthalpy using enthalpyMEAsol function
            Tstream_K = T[k] + 273.15
            h_stream = enthalpyMEAsol(MassesAndFracs[k], Tstream_K)
            hf[k] = h_stream
    
    # calculate enthalpies of combined streams and update hf list
    H4 = MassesAndFracs[3][0]*hf[3]
    H5 = MassesAndFracs[4][0]*hf[4]
    H6 = MassesAndFracs[5][0]*hf[5]
    H7 = H4 + H6 - H5
    h7 = H7/MassesAndFracs[6][0]
    hf[6] = h7
    
    return hf


# define function to calculate enthalpy of a gas stream
def enthalpyGases(MassAndFracs, Tstream_K):
    h_CO2 = MassAndFracs[1] * (hf[0] + (cpg[0] * (Tstream_K - Tref_K)))
    h_H2O = MassAndFracs[2] * (hf[1] + (cpg[1] * (Tstream_K - Tref_K)))
    h_N2 = MassAndFracs[3] * (hf[2] + (cpg[2] * (Tstream_K - Tref_K)))
    h_O2 = MassAndFracs[4] * (hf[3] + (cpg[3] * (Tstream_K - Tref_K)))
    h_stream = h_CO2 + h_H2O + h_N2 + h_O2

    return h_stream


def enthalpyMEAsol(MassAndFracs, Tstream_K):
    h_solution = MassAndFracs[5] * (hfsol + cp_integral(Tstream_K,cp_MEA_sol))
    h_CO2_dissolved = MassAndFracs[1] * (hf[0] + cp_integral(Tstream_K, cp_CO2))
    h_CO2_rx = MassAndFracs[1] * (habs_m/(Mw[0] * 1000)) 
    h_stream = h_solution + h_CO2_dissolved + h_CO2_rx
    return h_stream



def HeatExchangeV1(AbsEnthalpies):
    # Guess initial value for T7
    guess = np.array([300])
    # Find root of function FindT7 using scipy.optimize.root and initial guess
    ans = scipy.optimize.root(FindT7, guess)
    # Extract T7 from the solution
    T7 = ans['x'][0] - 273.15
    # Extract required enthalpies
    H4 = AbsEnthalpies[3]
    H5 = AbsEnthalpies[4]
    # Calculate delta_Tlm for heat exchanger
    delta_Tlm = Find_deltaT_lm(T7)
    # Calculate heat transfer rate
    Qv1 = (H5 - H4) * 1000
    # Calculate area of heat exchanger
    A = Qv1 / (U * delta_Tlm)
    return T7, A


def Find_deltaT_lm(Th_out):
    # Calculate deltaT_lm for heat exchanger given outlet temperature of hot stream
    deltaT_1 = T[5] - T[4]
    deltaT_2 = Th_out - T[3]
    a = np.log(deltaT_1 / deltaT_2)
    dtlm = (deltaT_1 - deltaT_2) / a
    return dtlm


def FindT7(x_list):
    # Use MassSimulator to get Masses and Fractions
    MassesAndFractions = MassSimulator()
    # Calculate enthalpies based on Masses and Fractions
    Enthalpies = enthalpies(MassesAndFractions)
    # Calculate absolute enthalpies
    AbsoluteEnthalpies = [MassesAndFractions[j][0] * Enthalpies[j] for j in range(len(Enthalpies))]
    T7 = x_list[0]
    # Calculate enthalpy of stream 7 using MEA solution enthalpy function
    H7 = AbsoluteEnthalpies[6]
    h7 = enthalpyMEAsol(MassesAndFractions[6], T7)
    # Calculate mass balance equation for stream 7
    eq1 = MassesAndFractions[6][0] * h7 - H7
    balance = [eq1]
    return balance


def CoolerV2(AbsEnthalpies):
    # Extract required enthalpies
    H3 = AbsEnthalpies[2]
    H7 = AbsEnthalpies[6]
    # Calculate heat transfer rate
    Qv2 = H3 - H7
    # Calculate mass flow rate of stream 10 based on heat transfer rate and specific heat
    T10 = T[9]
    T11 = T[10]
    change_per_kg = cp_integral(T11, cp_H2O, T0=T10)
    m10 = -Qv2 / change_per_kg
    return m10



# Define a function to calculate the cooling energy required in Cooler V3
def CoolerV3(MassesAndFracs):
    # Use specific temperature values from T list
    T8 = T[7]
    T12 = T[8]
    
    # Get necessary values for calculations from MassesAndFracs list
    wh8 = MassesAndFracs[7][2]
    m8 = MassesAndFracs[7][0]
    m9 = MassesAndFracs[8][0]
    
    # Calculate the delta heat of vaporization using values from Mw list
    delta_hvap = ((dHsub - dHfus)/Mw[1])*1000
    
    # Calculate the cooling energy required using the given formulas
    Qv3 =  (m9*cpg[0]*(T12 - T8)) + (wh8*m8*((cpg[1]*(T12 - T8)) - delta_hvap))
    
    return Qv3


# Define a function to calculate the heating energy required in Boiler V4
def BoilerV4(AbsEnthalpies, MassesAndFracs):
    # Get the cooling energy required in Cooler V3 using the CoolerV3 function
    Qv3 = CoolerV3(MassesAndFracs)
    
    # Get the absolute enthalpies required for the calculation from AbsEnthalpies list
    H5 = AbsEnthalpies[4]
    H6 = AbsEnthalpies[5]
    H9 = AbsEnthalpies[8]
    
    # Calculate the heating energy required using the given formulas
    Qv4 = H6 + H9 - Qv3 - H5
    
    return Qv4
