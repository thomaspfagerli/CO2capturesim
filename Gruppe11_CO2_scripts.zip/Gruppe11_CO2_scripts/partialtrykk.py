
import matplotlib.pyplot as plt
import numpy as np

# henry's constant as a function of temperature
# ---------------------------------------------------------------------
Hc = [None]*5
Hc[0] = 4.96563e2 # kPa m^3 mol^-1      c1
Hc[1] = 3.41697e5 # kPa m^3 mol^-1 K    c2
Hc[2] = 1.69131e0 # -                   c3
Hc[3] = 1.47225e3 # K                   c4
Hc[4] = 1.28338e5 # K^2                 c5

T = [273, 298, 313, 333, 353, 373, 393, 423] #K

K2 = [3.93e5, 3.70e4, 1.14e4, 2.43e3, 5.78e2, 2.46e2, 4.08e1, 6.74e0] #mol/m^3

T_const = T[0]
K2_const = K2[0] #ved T=273K
a = np.linspace(0,1,100) 

K_H = []
P_CO2 = []

for i in range(len(a)):
    
    K_H.append((Hc[0] + (Hc[1]*a[i]**2)/T_const) * np.exp(Hc[2]*a[i]**2 + Hc[3]/T_const + (Hc[4]*a[i])/T_const**2))
    
    P_CO2.append(K_H[i]*a[i]**2 / (K2_const*(1-2*a[i])**2))

plt.plot(a,P_CO2, "red")
plt.xlabel("Alpha [-]")
plt.ylabel("P_CO2 [kPa]")
plt.title(f"Konstant T = 273 degK")
plt.show()


# In[2]:


KH_2 = []
P_CO2_2 = []
a_const = 0.25

for i in range(len(K2)):
    
    KH_2.append((Hc[0] + (Hc[1]*a_const)/T[i]) * np.exp(Hc[2]*a_const**2 + Hc[3]/T[i] + (Hc[4]*a_const)/T[i]**2))
    
    P_CO2_2.append(KH_2[i]*a_const**2 / (K2[i]*(1-2*a_const)**2))

plt.plot(T,P_CO2_2, "red")
plt.xlabel("T [K]")
plt.ylabel("P_CO2 [Pa]")
plt.title(f"Konstant alpha = 0.25")
plt.show()

