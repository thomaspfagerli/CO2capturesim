from constants import *
from compression import *
from enthalpy import *
from MassBalance import *
from WtFrac import *

MassesAndFractions = MassSimulator()
Masses = [list[0] for list in MassesAndFractions]

Enthalpies = enthalpies(MassesAndFractions)
AbsoluteEnthalpies = [Masses[j]*Enthalpies[j] for j in range(len(Masses))]

# def one_step_compression(T1, Tout, p1, p2)
One_Step_Compression = one_step_compression(T[8]+273.15, 303, 2, 20)


# def three_step_compression(T1, p1, Tc, pb, Te, pd, Tout, pf)
Three_Step_Compression = three_step_compression(T[8]+273.15, p[8], 303, 4, 303, 8, 303, 20)

T7, A = HeatExchangeV1(AbsoluteEnthalpies)
m10 = CoolerV2(AbsoluteEnthalpies)
Qv3 = CoolerV3(MassesAndFractions)
Qv4 = BoilerV4(AbsoluteEnthalpies, MassesAndFractions)
EnergySolved = [T7, A, m10, Qv3, Qv4]

# Printing out the results
print("\n--- Result of mass simulator---\n")

print("Mass of streams: \n")
for i in range(len(MassesAndFractions)):
    x = MassesAndFractions[i]
    print(f'Stream {i+1} = {x[0]:.2f} kg/s')

print("\nMass fractions:\n")
for j in range(len(MassesAndFractions)):
    x = MassesAndFractions[j]
    print(f'Stream {j+1}: wC02 = {x[1]:.3f}, wH20 = {x[2]:.3f}, wN2 = {x[3]:.3f}, w02 = {x[4]:.3f}, wMEA = {x[5]:.3f}')

# Enthalpies
print("\nSpesific enthalpy for streams:\n")
for j in range(len(Enthalpies)):
    print(f"h{j + 1} = {Enthalpies[j]:.1f} kJ/kg")

print("\nAbsolute enthalpy for streams\n")
for j in range(len(AbsoluteEnthalpies)):
    print(f"H{j + 1} = {AbsoluteEnthalpies[j]/1000:.1f} MJ/s")
   
# Energy balances
print("\n\n--- Result of the energy balance over the V-components ---\n")

print("Heat exchanger V-1 (stream 7):")
print(f"Temperature = {EnergySolved[0]:.0f}C = {EnergySolved[0]+273:.0f}K")
print(f"Necessary area A = {EnergySolved[1]:.0f} m^2\n")

print("Cooler V-2")
print(f"Necessary flow rate for cooler in stream 1: {EnergySolved[2]:.0f} kg/s\n")

print("Cooler V-3")
print(f"Total energy consumption over cooler, QV-3 = {EnergySolved[3] / 1000:.1f} MW \n")

print("Heater V-4")
print(f"Total energy conspumtion of heater, QV-4 = {EnergySolved[4] / 1000:.1f} MW \n\n")

# Compressions
print("--- Result of compressions ---\n")

print('One-step:')
print(f"Total work per kilo: Ws = {One_Step_Compression[0]:.2f} kW/kg")
print(f"Total work in stream 9: Ws = {One_Step_Compression[0]*Masses[8]/1000:.2f} MW")
print(f"Total heat exchange per kilo: Q = {One_Step_Compression[1]:.2f} kW/kg")
print(f"Total heat exchange in stream 9: Q = {One_Step_Compression[1]*Masses[8]/1000:.2f} MW")
print(f"Temperature out of compressor: Tb = {One_Step_Compression[2]:.2f}K")
print("\n")

print('Three-step:')
print(f"Total work per kilo: Ws = {Three_Step_Compression[0]:.2f} kW/kg")
print(f"Totalt work in stream 9: Ws = {Three_Step_Compression[0]*Masses[8]/1000:.2f} MW")
print(f"Total heat exchange per kilo: Q = {Three_Step_Compression[1]:.2f} kW/kg")
print(f"Total heat exchange in stream 9: Q = {Three_Step_Compression[1]*Masses[8]/1000:.2f} MW")
print(f"Temperature out of the compressors: Tb = {Three_Step_Compression[2]:.2f}K, Td = {Three_Step_Compression[3]:.2f}K og Tf = {Three_Step_Compression[4]:.2f}K.\n")
