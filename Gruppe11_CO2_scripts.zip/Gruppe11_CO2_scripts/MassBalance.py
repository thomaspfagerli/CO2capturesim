import numpy as np
import scipy.optimize
from WtFrac import *

# Initialize variables
wmea1 = 0
wmea2 = 0

# Calculate weight fractions of CO2 for streams 3 and 4
wc3 = WtFracCO2(alpha3)
wc4 = WtFracCO2(alpha4)

# Initialize variables for streams 3 and 4
wh3, wn3, wo3 = 0, 0, 0
wh4, wn4, wo4 = 0, 0, 0

# Initialize variables for streams 5-7
wh5, wn5, wo5 = 0, 0, 0
wh6, wn6, wo6 = 0, 0, 0
wh7, wn7, wo7 = 0, 0, 0

# Calculate weight fractions of components for stream 8 and MEA weight fraction
Massefraksjon = MolarToWtFrac([xc8, 1 - xc8, 0, 0, 0])
wc8, wh8, wn8, wo8, wmea8 = Massefraksjon[0], Massefraksjon[1], Massefraksjon[2], Massefraksjon[3], Massefraksjon[4]

# Initialize variables for stream 9
wc9, wh9, wn9, wo9, wmea9 = wc9, 0, 0, 0, 0

def SolveMassSimulator(x_list):
    # Define unknown variables
    wc2, wh2, wn2, wo2, m2 = x_list[:5]
    wmea3, m3 = x_list[5:7]
    wmea4, m4 = x_list[7:9]
    wc5, wmea5, m5 = x_list[9:12]
    wc6, wmea6, m6 = x_list[12:15]
    wc7, wmea7, m7 = x_list[15:18]
    m8, m9 = x_list[18:]

    # Define mass balances for each component in each control volume
    eq1 = m1 + m3 - m2 - m4
    eq2 = wc1 * m1 + wc3 * m3 - wc2 * m2 - wc4 * m4
    eq3 = wh1 * m1 + wh3 * m3 - wh2 * m2 - wh4 * m4
    eq4 = wn1 * m1 + wn3 * m3 - wn2 * m2 - wn4 * m4
    eq5 = wo1 * m1 + wo3 * m3 - wo2 * m2 - wo4 * m4
    eq6 = m4 - m5
    eq7 = wc4 - wc5
    eq8 = wmea4 - wmea5
    eq9 = m3 - m6
    eq10 = wc3 - wc6
    eq11 = wmea3 - wmea6
    eq12 = wc9 * m9 + wc6 * m6 - wc5 * m5
    eq13 = wmea9 * m9 + wmea6 * m6 - wmea5 * m5
    eq14 = m3 - m7
    eq15 = wc3 - wc7
    eq16 = wmea3 - wmea7
    eq17 = wc1 * m1 * (1 - wcapture) - wc2 * m2
    eq18 = wmea3 + wc3 - 1
    eq19 = wmea4 + wc4 - 1
    eq20 = wc8 * m8 - wc9 * m9

    balance = [eq1, eq2, eq3, eq4, eq5, eq6, eq7, eq8, eq9, eq10, eq11,
               eq12, eq13, eq14, eq15, eq16, eq17, eq18, eq19, eq20]

    return balance

def MassSimulator():
    guess = np.array([0.04, 0.06, 0.84, 0.12, 750, 0.94, 820, 0.88, 860, 0.08, 0.92, 860, 0.06, 0.94, 820, 0.04, 0.96, 820, 110, 55])
    ans = scipy.optimize.root(SolveMassSimulator, guess)
    sol = ans['x']
    wc2 = sol[0]
    wh2 = sol[1]
    wn2 = sol[2]
    wo2 = sol[3]
    m2 = sol[4]
    wmea3 = sol[5]
    m3 = sol[6]
    wmea4 = sol[7]
    m4 = sol[8]
    wc5 = sol[9]
    wmea5 = sol[10]
    m5 = sol[11]
    wc6 = sol[12]
    wmea6 = sol[13]
    m6 = sol[14]
    wc7 = sol[15]
    wmea7 = sol[16]
    m7 = sol[17]
    m8 = sol[18]
    m9 = sol[19]

    Liste = np.array([m1, wc1, wh1, wn1, wo1, wmea1,
                      m2, wc2, wh2, wn2, wo2, wmea2,
                      m3, wc3, wh3, wn3, wo3, wmea3,
                      m4, wc4, wh4, wn4, wo4, wmea4,
                      m5, wc5, wh5, wn5, wo5, wmea5,
                      m6, wc6, wh6, wn6, wo6, wmea6,
                      m7, wc7, wh7, wn7, wo7, wmea7,
                      m8, wc8, wh8, wn8, wo8, wmea8,
                      m9, wc9, wh9, wn9, wo9, wmea9])
    
    return Liste.reshape(9, 6)