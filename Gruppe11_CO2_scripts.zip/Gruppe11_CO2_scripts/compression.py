from constants import *

# Function to calculate the temperature after compression
def T_after_compression(T1, p1, p2, cp=cpg[0] * Mw[0]):
    """
    Calculates the temperature after compression using the following formula:
    T2 = (T1 / eta) * ((p2 / p1) ** (gasConst / cp) - 1) + T1

    Args:
    T1: Temperature before compression
    p1: Pressure before compression
    p2: Pressure after compression
    cp: Specific heat capacity of gas

    Returns:
    T2: Temperature after compression
    """
    T2 = (T1 / eta) * ((p2 / p1) ** (gasConst / cp) - 1) + T1
    return T2


# Function to calculate heat exchange
def heat_exchange(T1, T2, cp=cpg[0] * Mw[0]):
    """
    Calculates the heat exchange using the following formula:
    Q = cp * (T2 - T1)

    Args:
    T1: Temperature before heat exchange
    T2: Temperature after heat exchange
    cp: Specific heat capacity of gas

    Returns:
    Q: Heat exchange
    """
    Q =  cp * (T2 - T1)
    return Q


# Function to calculate shaft work during compression
def shaftwork_compression(T1, p1, p2, cp=cpg[0] * Mw[0]):
    """
    Calculates the shaft work during compression using the following formula:
    Ws = (cp / eta) * T1 * (((p2 / p1) ** (gasConst / cp)) - 1)

    Args:
    T1: Temperature before compression
    p1: Pressure before compression
    p2: Pressure after compression
    cp: Specific heat capacity of gas

    Returns:
    Ws: Shaft work during compression
    """
    Ws = (cp / eta) * T1 * (((p2 / p1) ** (gasConst / cp)) - 1)
    return Ws


# Function to calculate the parameters after one-step compression
def one_step_compression(T1, Tout, p1, p2, cp=cpg[0] * Mw[0]):
    """
    Calculates the parameters after one-step compression, i.e., shaft work, heat exchange, and temperature after compression.

    Args:
    T1: Temperature before compression
    Tout: Temperature after heat exchange
    p1: Pressure before compression
    p2: Pressure after compression
    cp: Specific heat capacity of gas

    Returns:
    [Ws, Q, T2]: List of shaft work, heat exchange, and temperature after compression
    """
    Ws = shaftwork_compression(T1, p1, p2, cp)
    T2 = T_after_compression(T1, p1, p2, cp)
    Q = heat_exchange(T2, Tout, cp)
    return [Ws, Q, T2]


# Function to calculate the parameters after three-step compression
def three_step_compression(T1, p1, Tc, pb, Te, pd, Tout, pf, cp=cpg[0] * Mw[0]):  
    # Calculate work done in each compression stage
    Wb = shaftwork_compression(T1, p1, pb, cp)
    Wd = shaftwork_compression(Tc, pb, pd, cp)
    Wf = shaftwork_compression(Te, pd, pf, cp)
    # Calculate total work done
    WsTotal = Wb + Wd + Wf

    # Calculate temperatures after each compression stage
    Tb = T_after_compression(T1, p1, pb, cp)
    Td = T_after_compression(Tc, pb, pd, cp)
    Tf = T_after_compression(Te, pd, pf, cp)

    # Calculate heat exchange at each stage
    Qc = heat_exchange(Tb, Tc, cp)
    Qe = heat_exchange(Td, Te, cp)
    Qout = heat_exchange(Tf, Tout, cp)
    # Calculate total heat exchange
    QTotal = Qc + Qe + Qout

    # Return a list containing the total work done, total heat exchange, and temperatures after each stage
    return [WsTotal, QTotal, Tb, Td, Tf]
